CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

CREATE TABLE IF NOT EXISTS products (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    supplier VARCHAR(150),
    quantity INT NOT NULL DEFAULT 0,
    price DECIMAL(10,2) NOT NULL,
    CHECK (quantity >= 0),
    CHECK (price >= 0)
);

INSERT INTO products (name, category, supplier, quantity, price)
VALUES
('Laptop', 'Electronics', 'ABC Suppliers', 10, 50000.00),
('Mouse', 'Computer Accessories', 'Smart Supplies', 3, 500.00),
('Notebook', 'Office Supplies', 'City Traders', 25, 60.00);
