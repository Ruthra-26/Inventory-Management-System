const API_URL = "http://localhost:8080/api/products";
const form = document.getElementById("productForm");
const table = document.getElementById("productTable");
let allProducts = [];

async function apiRequest(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    throw new Error("Request failed: " + response.status);
  }
  if (response.status === 204) return null;
  return response.json();
}

async function loadProducts() {
  try {
    allProducts = await apiRequest(API_URL);
    displayProducts(allProducts);
    updateDashboard(allProducts);
  } catch (error) {
    console.error(error);
    alert("Unable to load products. Make sure the Spring Boot backend and MySQL are running.");
  }
}

function displayProducts(products) {
  table.innerHTML = "";

  products.forEach(product => {
    const row = document.createElement("tr");
    const values = [
      product.id,
      product.name,
      product.category || "-",
      product.supplier || "-",
      product.quantity,
      Number(product.price).toFixed(2),
      (Number(product.quantity) * Number(product.price)).toFixed(2)
    ];

    values.forEach(value => {
      const cell = document.createElement("td");
      cell.textContent = value ?? "";
      row.appendChild(cell);
    });

    if (Number(product.quantity) < 5) row.classList.add("low-stock");

    const actionCell = document.createElement("td");
    const editButton = document.createElement("button");
    editButton.textContent = "Edit";
    editButton.className = "edit-button";
    editButton.addEventListener("click", () => editProduct(product));

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.className = "delete-button";
    deleteButton.addEventListener("click", () => deleteProduct(product.id));

    actionCell.append(editButton, deleteButton);
    row.appendChild(actionCell);
    table.appendChild(row);
  });
}

function updateDashboard(products) {
  document.getElementById("totalProducts").textContent = products.length;

  const lowCount = products.filter(p => Number(p.quantity) < 5).length;
  document.getElementById("lowStock").textContent = lowCount;

  const stockCount = products.reduce((sum, p) => sum + Number(p.quantity), 0);
  document.getElementById("totalStock").textContent = stockCount;

  const value = products.reduce(
    (sum, p) => sum + Number(p.quantity) * Number(p.price), 0
  );
  document.getElementById("inventoryValue").textContent = "₹" + value.toFixed(2);
}

function editProduct(product) {
  document.getElementById("productId").value = product.id;
  document.getElementById("productName").value = product.name;
  document.getElementById("category").value = product.category || "";
  document.getElementById("supplier").value = product.supplier || "";
  document.getElementById("quantity").value = product.quantity;
  document.getElementById("price").value = product.price;
  document.getElementById("addProduct").scrollIntoView({ behavior: "smooth" });
}

form.addEventListener("submit", async event => {
  event.preventDefault();

  const id = document.getElementById("productId").value;
  const product = {
    name: document.getElementById("productName").value.trim(),
    category: document.getElementById("category").value.trim(),
    supplier: document.getElementById("supplier").value.trim(),
    quantity: Number(document.getElementById("quantity").value),
    price: Number(document.getElementById("price").value)
  };

  if (!product.name || !product.category || product.quantity < 0 || product.price < 0) {
    alert("Enter valid product details.");
    return;
  }

  const url = id ? `${API_URL}/${id}` : API_URL;
  const method = id ? "PUT" : "POST";

  try {
    await apiRequest(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(product)
    });
    alert(id ? "Product updated!" : "Product added!");
    form.reset();
    document.getElementById("productId").value = "";
    await loadProducts();
  } catch (error) {
    console.error(error);
    alert("Unable to save product.");
  }
});

async function deleteProduct(id) {
  if (!confirm("Do you want to delete this product?")) return;

  try {
    await apiRequest(`${API_URL}/${id}`, { method: "DELETE" });
    await loadProducts();
    alert("Product deleted successfully!");
  } catch (error) {
    console.error(error);
    alert("Unable to delete product.");
  }
}

document.getElementById("searchButton").addEventListener("click", () => {
  const term = document.getElementById("searchBox").value.trim().toLowerCase();
  const result = allProducts.filter(p => p.name.toLowerCase().includes(term));
  displayProducts(result);
});

document.getElementById("showAllButton").addEventListener("click", () => {
  displayProducts(allProducts);
});

document.getElementById("lowStockButton").addEventListener("click", () => {
  displayProducts(allProducts.filter(p => Number(p.quantity) < 5));
});

document.getElementById("clearButton").addEventListener("click", () => {
  document.getElementById("productId").value = "";
});

document.getElementById("exportButton").addEventListener("click", () => {
  const headings = ["ID", "Product", "Category", "Supplier", "Quantity", "Price"];
  const rows = allProducts.map(p => [
    p.id, p.name, p.category || "", p.supplier || "", p.quantity, p.price
  ]);

  const csv = [headings, ...rows]
    .map(row => row.map(value =>
      `"${String(value ?? "").replace(/"/g, '""')}"`
    ).join(","))
    .join("\n");

  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const objectUrl = URL.createObjectURL(blob);
  link.href = objectUrl;
  link.download = "inventory-report.csv";
  link.click();
  URL.revokeObjectURL(objectUrl);
});

loadProducts();
